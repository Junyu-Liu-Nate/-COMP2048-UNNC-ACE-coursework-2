// Junyu LIU 20216355

import java.util.ArrayList;
import java.util.Scanner;
import java.util.Stack;
import java.util.StringTokenizer;

public class Main {
    public static void main(String[] args) {
        // Read the user input, and sepertae the input string into an ArrayList of tokens.
        ArrayList<String> LD_Infix = new ArrayList<>();
        LD_Infix = ReadInput();

        // Convert the Infix-represented ArrayList of tokens into a suffix-represented list, in oder to prepare for puting it into a tree.
        ArrayList<String> LD_Suffix = new ArrayList<>();
        LD_Suffix = ConvertToSuffix(LD_Infix);

        // Create a tree and put the tokens in the suffix-represented list into the tree.
        ParseTree logicTree = buildTree(LD_Suffix);

        // Traverse the tree, check and change the traversed node if its traversable.
        int num_transferable = logicTree.traverseTreeCheck(logicTree.root);
        logicTree.resetNumTransferable();
        while (num_transferable != 0) {
            logicTree.traverseTree(logicTree.root);

            num_transferable = logicTree.traverseTreeCheck(logicTree.root);
            logicTree.resetNumTransferable();
        }

        // Traverse the tree and output the final outcome.
        String temp = logicTree.printMe(logicTree.root);
        System.out.println(temp);
    }

    // Read the user input, and sepertae the input string into an ArrayList of tokens.
    public static ArrayList<String> ReadInput() {
        System.out.print("Please input an LD propositional logic formula containing: [ , ] , & , | , ~ , ->\n>>  ");
        String LDstr = new Scanner(System.in).nextLine();

        ArrayList<String> LDliterals = new ArrayList<>();
        StringTokenizer literalToken = new StringTokenizer(LDstr, " ");
        while (literalToken.hasMoreTokens()) {
            String temp = literalToken.nextToken();
            LDliterals.add(temp);
        }

        return LDliterals;
    }

    // Convert the Infix-represented ArrayList of tokens into a suffix-represented list, in oder to prepare for puting it into a tree.
    public static ArrayList<String> ConvertToSuffix(ArrayList<String> strInfix) {
        ArrayList<String> strSuffix = new ArrayList<>();
        Stack<String> strStack = new Stack<>();

        for (int i = 0; i < strInfix.size(); i++) {
            String str = strInfix.get(i);
            if (str.equals("[") | str.equals("&") | str.equals("|") | str.equals("~") | str.equals("->")) {
                strStack.push(str);
            } else if (str.equals("]")) {
                while (!strStack.peek().equals("[")) {
                    strSuffix.add(strStack.pop());
                }
                strStack.pop();
            } else {
                strSuffix.add(str);
            }
        }

        if (!strStack.empty()) {
            strSuffix.add(strStack.pop());
        }

        return strSuffix;
    }

    // Create a tree and put the tokens in the suffix-represented list into the tree.
    public static ParseTree buildTree(ArrayList<String> LD_suffix) {
        Stack treeStack = new Stack();

        for (int i = 0; i < LD_suffix.size(); i++) {
            String str = LD_suffix.get(i);
            if (!str.equals("->") & !str.equals("~") & !str.equals("&") & !str.equals("|")) {
                Node node = new Node(str);
                treeStack.push(node);
            } else if(str.equals("~")) {
                Node node = new Node(str);
                Node rightNode = (Node)treeStack.pop();

                Node leftNode = null;
                node.setLeftChild(leftNode);
                node.setRightChild(rightNode);
                treeStack.push(node);
            } else {
                Node node = new Node(str);
                Node rightNode = (Node)treeStack.pop();
                Node leftNode = (Node)treeStack.pop();
                node.setLeftChild(leftNode);
                node.setRightChild(rightNode);
                treeStack.push(node);
            }
        }

        return new ParseTree((Node) treeStack.pop());
    }
}

class Node {
    String strLiteral; // String value of the node.
    Node leftChild; // A reference to its left child node (which node to point to).
    Node rightChild; // A reference to its right child node (which node to point to).

    // The constructor of the Node class.
    Node(String strLiteral) {
        this.strLiteral = strLiteral;
    }

    // Set the value (which node to point to) of the left child of the current node.
    void setLeftChild(Node leftChild) {
        this.leftChild = leftChild;
    }

    // Set the value (which node to point to) of the right child of the current node.
    void setRightChild(Node rightChild) {
        this.rightChild = rightChild;
    }

    // Check whether the current node is a leaf node.
    boolean isLeaf() {
        if (leftChild == null & rightChild == null) {
            return true;
        } else {
            return false;
        }
    }

    // Check whether the left branch of the current node equals to its right branch.
    boolean isEqual(Node node1, Node node2) {
        if (node1.isLeaf() & node2.isLeaf()) {
            return node1.strLiteral.equals(node2.strLiteral);
        } else if (node1.isLeaf() & !node2.isLeaf()) {
            return false;
        } else if (!node1.isLeaf() & node2.isLeaf()) {
            return false;
        } else if (!node1.strLiteral.equals(node2.strLiteral)) {
            return false;
        } else if (node1.strLiteral.equals("~") & node2.strLiteral.equals("~")) {
            return node1.strLiteral.equals(node2.strLiteral) & isEqual(node1.rightChild, node2.rightChild);
        } else {
            return node1.strLiteral.equals(node2.strLiteral) & isEqual(node1.leftChild, node2.leftChild) & isEqual(node1.rightChild, node2.rightChild);
        }
    }
}

class ParseTree {
    Node root; // The root node of the tree.
    private static int numTransferable; // The number of transferable nodes (e.g. containing a node with literal "->") in the tree.

    ParseTree(Node root) {
        this.root = root;
        numTransferable = 0;
    }

    // Traverse through the tree following preorder traversal, and change the traversed node if its traversable.
    public static void traverseTree(Node node) {
        Node currentNode = node;

        if (currentNode != null) {
            if (currentNode.rightChild != null) {
                if (checkTransform(currentNode) == true) {
                    currentNode = doTransform(currentNode);
                    traverseTree(currentNode.leftChild);
                    traverseTree(currentNode.rightChild);
                } else {
                    traverseTree(currentNode.leftChild);
                    traverseTree(currentNode.rightChild);
                }
            }
        }
    }

    // Traverse through the tree following preorder traversal and return the numebr of transferable nodes.
    public static int traverseTreeCheck(Node node) {
        Node currentNode = node;

        if (currentNode != null) {
            if (checkTransform(currentNode) == true) {
                numTransferable++;
            }
            traverseTreeCheck(currentNode.leftChild);
            traverseTreeCheck(currentNode.rightChild);
        }

        return numTransferable;
    }

    // reset numTransferable to 0.
    public void resetNumTransferable() {
        numTransferable = 0;
    }

    // Check whether the current node is transferable (satisfy the transfer rules).
    public static boolean checkTransform(Node node) {
        Node currentNode = node;

        if (currentNode.strLiteral.equals("->")) {
            return true;
        }

        if (currentNode.strLiteral.equals("~")) {
            if (currentNode.rightChild.strLiteral.equals("~")) {
                return true;}
            if (currentNode.rightChild.strLiteral.equals("&")) {
                return true;}
            if (currentNode.rightChild.strLiteral.equals("|")) {
                return true;}
            if (currentNode.rightChild.strLiteral.equals("T")) {
                return true;}
            if (currentNode.rightChild.strLiteral.equals("F")) {
                return true;}
        }

        if (currentNode.strLiteral.equals("&")) {
            if (currentNode.rightChild.strLiteral.equals("|")) {
                return true;}
            if (currentNode.leftChild.strLiteral.equals("|")) {
                return true;}

            if (currentNode.isEqual(currentNode.leftChild, currentNode.rightChild)) {
                return true;}

            if (currentNode.rightChild.rightChild != null) {
                if (currentNode.rightChild.strLiteral.equals("~")
                        & currentNode.isEqual(currentNode.leftChild, currentNode.rightChild.rightChild)) {
                    return true;}
            }

            if (currentNode.leftChild.rightChild != null) {
                if (currentNode.leftChild.strLiteral.equals("~")
                        & currentNode.isEqual(currentNode.rightChild, currentNode.leftChild.rightChild)) {
                    return true;}
            }

            if (currentNode.leftChild.equals("T") & currentNode.rightChild.isLeaf()) {
                return true;}
            if (currentNode.leftChild.equals("F") & currentNode.rightChild.isLeaf()) {
                return true;}
            if (currentNode.rightChild.equals("T") & currentNode.leftChild.isLeaf()) {
                return true;}
            if (currentNode.rightChild.equals("F") & currentNode.rightChild.isLeaf()) {
                return true;}
        }

        if (currentNode.strLiteral.equals("|")) {
            if (currentNode.isEqual(currentNode.leftChild, currentNode.rightChild)) {
                return true;}
            if (currentNode.rightChild.rightChild != null) {
                if (currentNode.rightChild.strLiteral.equals("~")
                        & currentNode.isEqual(currentNode.leftChild, currentNode.rightChild.rightChild)) {
                    return true;}
            }
            if (currentNode.leftChild.rightChild != null) {
                if (currentNode.leftChild.strLiteral.equals("~")
                        & currentNode.isEqual(currentNode.rightChild, currentNode.leftChild.rightChild)) {
                    return true;}
            }
            if (currentNode.leftChild.strLiteral.equals("T") & currentNode.rightChild.isLeaf()) {
                return true;}
            if (currentNode.leftChild.strLiteral.equals("F") & currentNode.rightChild.isLeaf()) {
                return true;}
            if (currentNode.rightChild.strLiteral.equals("T") & currentNode.leftChild.isLeaf()) {
                return true;}
            if (currentNode.rightChild.strLiteral.equals("F") & currentNode.leftChild.isLeaf()) {
                return true;}
        }

        return false;
    }

    // Change the traversed node if its traversable.
    public static Node doTransform(Node node) {
        Node currentNode = node;

        if (currentNode.strLiteral.equals("->")) {
            Node newNode = new Node("~");
            currentNode.strLiteral = "|";
            newNode.setRightChild(currentNode.leftChild);
            currentNode.setLeftChild(newNode);

            return currentNode;
        }

        if (currentNode.strLiteral.equals("~")) {
            if (currentNode.rightChild.strLiteral.equals("~")) {
                currentNode.strLiteral = currentNode.rightChild.rightChild.strLiteral;
                if (currentNode.rightChild.rightChild.isLeaf()) {
                    currentNode.setLeftChild(null);
                    currentNode.setRightChild(null);
                } else {
                    currentNode.setLeftChild(currentNode.rightChild.rightChild.leftChild);
                    currentNode.setRightChild(currentNode.rightChild.rightChild.rightChild);
                }
                return currentNode;
            }

            if (currentNode.rightChild.strLiteral.equals("&")) {
                currentNode.strLiteral = "|";
                Node newNode = new Node("~");
                currentNode.setLeftChild(newNode);
                newNode.setRightChild(currentNode.rightChild.leftChild);
                currentNode.rightChild.strLiteral = "~";
                currentNode.rightChild.setLeftChild(null);
                return currentNode;
            }

            if (currentNode.rightChild.strLiteral.equals("|")) {
                currentNode.strLiteral = "&";
                Node newNode = new Node("~");
                currentNode.setLeftChild(newNode);
                newNode.setRightChild(currentNode.rightChild.leftChild);
                currentNode.rightChild.strLiteral = "~";
                currentNode.rightChild.setLeftChild(null);
                return currentNode;
            }

            if (currentNode.rightChild.strLiteral.equals("T")) {
                currentNode.strLiteral = "F";
                currentNode.setLeftChild(null);
                currentNode.setRightChild(null);
                return currentNode;
            }

            if (currentNode.rightChild.strLiteral.equals("F")) {
                currentNode.strLiteral = "T";
                currentNode.setLeftChild(null);
                currentNode.setRightChild(null);
                return currentNode;
            }
        }

        if (currentNode.strLiteral.equals("&")) {
            if (currentNode.rightChild.strLiteral.equals("|")) {
                currentNode.strLiteral = "|";
                Node newNode = new Node("&");
                newNode.setLeftChild(currentNode.leftChild);
                newNode.setRightChild(currentNode.rightChild.leftChild);
                currentNode.rightChild.strLiteral = "&";
                currentNode.rightChild.setLeftChild(currentNode.leftChild);
                currentNode.setLeftChild(newNode);
                return currentNode;
            }

            if (currentNode.leftChild.strLiteral.equals("|")) {
                currentNode.strLiteral = "|";
                Node newNode = new Node("&");
                newNode.setLeftChild(currentNode.leftChild.rightChild);
                newNode.setRightChild(currentNode.rightChild);
                currentNode.leftChild.strLiteral = "&";
                currentNode.leftChild.setRightChild(currentNode.rightChild);
                currentNode.setRightChild(newNode);
                return currentNode;
            }

            if (currentNode.isEqual(currentNode.leftChild, currentNode.rightChild)) {
                currentNode.strLiteral = currentNode.leftChild.strLiteral;
                if (currentNode.leftChild.isLeaf()) {
                    currentNode.setLeftChild(null);
                    currentNode.setRightChild(null);
                } else {
                    currentNode.setLeftChild(currentNode.leftChild.leftChild);
                    currentNode.setRightChild(currentNode.leftChild.rightChild);
                }
                return currentNode;
            }

            if (currentNode.rightChild.rightChild != null) {
                if (currentNode.rightChild.strLiteral.equals("~")
                        & currentNode.isEqual(currentNode.leftChild, currentNode.rightChild.rightChild)) {
                    currentNode.strLiteral = "F";
                    currentNode.setLeftChild(null);
                    currentNode.setRightChild(null);
                    return currentNode;
                }
            }

            if (currentNode.leftChild.rightChild != null) {
                if (currentNode.leftChild.strLiteral.equals("~")
                        & currentNode.isEqual(currentNode.rightChild, currentNode.leftChild.rightChild)) {
                    currentNode.strLiteral = "F";
                    currentNode.setLeftChild(null);
                    currentNode.setRightChild(null);
                    return currentNode;
                }
            }

            if (currentNode.leftChild.equals("T") & currentNode.rightChild.isLeaf()) {
                currentNode = currentNode.rightChild;
                return currentNode;
            }

            if (currentNode.leftChild.equals("F") & currentNode.rightChild.isLeaf()) {
                currentNode.strLiteral = "F";
                currentNode.setLeftChild(null);
                currentNode.setRightChild(null);
                return currentNode;
            }

            if (currentNode.rightChild.equals("T") & currentNode.leftChild.isLeaf()) {
                currentNode = currentNode.leftChild;
                return currentNode;
            }

            if (currentNode.rightChild.equals("F") & currentNode.rightChild.isLeaf()) {
                currentNode.strLiteral = "F";
                currentNode.setLeftChild(null);
                currentNode.setRightChild(null);
                return currentNode;
            }
        }

        if (currentNode.strLiteral.equals("|")) {
            if (currentNode.isEqual(currentNode.leftChild, currentNode.rightChild)) {
                currentNode.strLiteral = currentNode.leftChild.strLiteral;
                if (currentNode.leftChild.isLeaf()) {
                    currentNode.setLeftChild(null);
                    currentNode.setRightChild(null);
                } else {
                    currentNode.setLeftChild(currentNode.leftChild.leftChild);
                    currentNode.setRightChild(currentNode.leftChild.rightChild);
                }
                return currentNode;
            }

            if (currentNode.rightChild.rightChild != null) {
                if (currentNode.rightChild.strLiteral.equals("~")
                        & currentNode.isEqual(currentNode.leftChild, currentNode.rightChild.rightChild)) {
                    currentNode.strLiteral = "T";
                    currentNode.setLeftChild(null);
                    currentNode.setRightChild(null);
                    return currentNode;
                }
            }

            if (currentNode.leftChild.rightChild != null) {
                if (currentNode.leftChild.strLiteral.equals("~")
                        & currentNode.isEqual(currentNode.rightChild, currentNode.leftChild.rightChild)) {
                    currentNode.strLiteral = "T";
                    currentNode.setLeftChild(null);
                    currentNode.setRightChild(null);
                    return currentNode;
                }
            }

            if (currentNode.leftChild.strLiteral.equals("T") & currentNode.rightChild.isLeaf()) {
                currentNode.strLiteral = "T";
                currentNode.setLeftChild(null);
                currentNode.setRightChild(null);
                return currentNode;
            }

            if (currentNode.leftChild.strLiteral.equals("F") & currentNode.rightChild.isLeaf()) {
                currentNode = currentNode.rightChild;
                return currentNode;
            }

            if (currentNode.rightChild.strLiteral.equals("T") & currentNode.leftChild.isLeaf()) {
                currentNode.strLiteral = "T";
                currentNode.setLeftChild(null);
                currentNode.setRightChild(null);
                return currentNode;
            }

            if (currentNode.rightChild.strLiteral.equals("F") & currentNode.leftChild.isLeaf()) {
                currentNode = currentNode.leftChild;
                return currentNode;
            }
        }

        return currentNode;
    }

    // Traverse through the tree following preorder traversal and merge the literals of all the nodes into a single string, as the final output.
    public static String printMe(Node node) {
        //System.out.println(node.strLiteral);

        if (node == null) {
            //System.out.println("null situation");
            return "";
        } else if (node.isLeaf()) {
            //System.out.println("leaf situation");
            return node.strLiteral;
        } else if (node.strLiteral.equals("~")) {
            //System.out.println("Not situation");
            return node.strLiteral + " [ " + printMe(node.rightChild) + " ]";
        } else {
            //System.out.println("normal situation");
            return "[ " + printMe(node.leftChild) + " ] " + node.strLiteral + " [ " + printMe(node.rightChild) + " ]";
        }
    }
}
